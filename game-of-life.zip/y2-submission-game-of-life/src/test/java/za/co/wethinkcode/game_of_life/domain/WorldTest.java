package za.co.wethinkcode.game_of_life.domain;

import org.junit.jupiter.api.Test;

public class WorldTest {

    @Test
    public void testDeathByUnderPopulation(){
        // COMPLETE THIS
    }

    @Test
    public void testStillAliveInNextStep(){
        // COMPLETE THIS
    }

    @Test
    public void testDeathByOverPopulation(){
        // COMPLETE THIS
    }

    @Test
    public void testBirthByReproduction(){
        // COMPLETE THIS
    }
}
