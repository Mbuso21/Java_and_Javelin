package za.co.wethinkcode.game_of_life.database;

public class GameDbConnect {

}
