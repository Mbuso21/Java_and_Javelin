package za.co.wethinkcode.game_of_life.database;

import za.co.wethinkcode.game_of_life.domain.World;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GameDB {

    public void createDataBase() {
        // Open a connection
        try(Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/");
            Statement stmt = conn.createStatement();
        ) {
            String sql = "CREATE DATABASE GAME";
            stmt.executeUpdate(sql);
            System.out.println("Database created successfully...");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void createData( final Connection connection )
            throws SQLException
    {
        try( final Statement stmt = connection.createStatement() ){
            boolean gotAResultSet = stmt.execute(
                    "" );
            if( gotAResultSet ){
                throw new RuntimeException( "Unexpectedly got a SQL resultset." );
            }else{
                final int updateCount = stmt.getUpdateCount();
                if( updateCount == 1 ){
                    System.out.println( "1 row INSERTED into ingredients" );
                }else{
                    throw new RuntimeException( "Expected 1 row to be inserted, but got " + updateCount );
                }
            }
        }
    }

}
