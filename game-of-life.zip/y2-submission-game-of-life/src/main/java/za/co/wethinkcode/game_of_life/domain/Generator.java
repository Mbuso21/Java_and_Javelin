package za.co.wethinkcode.game_of_life.domain;

public class Generator {

    public Generator() {}

    /**
     * Calculates the state of the world after the epoch
     * @param initialEpoch and epoch number
     * @return state after the epoch
     */
    public int[][] epochGenerator(int[][] initialEpoch, int epoch) {
        int[][] finalEpoch = {      {0, 0, 0},
                                    {0, 0, 0},
                                    {0, 0, 0}};
        return  finalEpoch;
    }
}
